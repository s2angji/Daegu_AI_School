
Thermal Cheetah - v1 square
==============================

This dataset was exported via roboflow.ai on November 28, 2020 at 9:58 PM GMT

It includes 129 images.
Cheetah are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


