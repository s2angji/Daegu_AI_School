
Wildfire Smoke - v1 raw
==============================

This dataset was exported via roboflow.ai on October 13, 2020 at 7:17 AM GMT

It includes 737 images.
Smoke are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


